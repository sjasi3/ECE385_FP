#ifndef AUTOUPDATER_H
#define AUTOUPDATER_H

void initAutoupdater();
void checkUpdatesUi();
void shutdownAutoupdater();

#endif // AUTOUPDATER_H
