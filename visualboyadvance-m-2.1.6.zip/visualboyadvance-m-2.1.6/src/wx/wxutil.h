#ifndef _WX_UTIL_H
#define _WX_UTIL_H

#include <wx/event.h>

int getKeyboardKeyCode(const wxKeyEvent& event);

#endif
