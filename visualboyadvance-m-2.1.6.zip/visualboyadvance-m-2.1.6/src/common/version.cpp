#include "version_cpp.h"
#include "version.h"

const char* const vba_name_and_subversion = VBA_NAME_AND_SUBVERSION;

const char* const vbam_version = VBAM_VERSION;
