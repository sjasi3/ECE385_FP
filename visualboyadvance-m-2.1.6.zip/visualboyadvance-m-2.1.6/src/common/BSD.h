#ifndef VBAM_BSD_H
#define VBAM_BSD_H

#define fopen64     fopen
#define fseeko64    fseeko
#define fseek64     fseek
#define ftell64     ftell
#define ftello64    ftello

#endif // VBAM_BSD_H

