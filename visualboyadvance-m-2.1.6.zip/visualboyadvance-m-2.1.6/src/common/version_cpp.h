#ifndef VBAM_VERSION_CPP_H
#define VBAM_VERSION_CPP_H

extern const char* const vba_name_and_subversion;

extern const char* const vbam_version;

#endif /* VBAM_VERSION_CPP_H */
